<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @copyright  Copyright 2010-2015 SEConfig Team
 * @version    $Id: Core.php 480 2015-03-19 05:59 Reza $
 * @author     Reza
 */

class Anyx_Api_Core extends Core_Api_Abstract {
        
}