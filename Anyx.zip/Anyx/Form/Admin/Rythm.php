<?php
/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    
 * @copyright  Copyright 
 * @license    
 * @version    $Id: Global.php 1010 2021-08-11 2:20:25Z reza $
 * @author     
 */
class Anyx_Form_Admin_Rythm extends Engine_Form {
  public function init() {
    $this
      ->setTitle('')
      ->setDescription('If your settings, is done, Please click on Save Changes');

    // Add submit button
    $this->addElement('Button', 'save', array(
      'label' => 'Save Changes in Rythm form',
      'type' => 'submit',
      'ignore' => true
    ));

  }

}
